This directory holds header files for things which are exposed as part
of the internal API of a library, but shouldn't be exposed to
externally.
