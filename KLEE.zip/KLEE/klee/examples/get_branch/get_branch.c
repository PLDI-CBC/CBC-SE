/*  * test the branches  */

#include "klee/klee.h"
#include <string.h>
#include <stdlib.h>

int get_branch(int x, int y, int z) {
  int a , b, c, d;
	if(x > 0)
	{
		a = 2;
	}
	if(y > 1){
		b = 2;
	}
	if(z < 2){
		c = 2;
	}
	return 1 / (b - c);
} 

// int get_branch(int x, int y, int z){
// 	char *s = NULL;
// 	int a , b , c ;
// 	a = 4 ;
// 	if ( x > 1 )
// 		a = 2 ;
// 	if ( y < 1 )
// 		b = 0 ;
// 	else
// 		b = 2 ;
// 	if ( z < 2 )
// 		c = z ;
// 	else
// 		c = 4 ;
// 	s = (char *) malloc(a - b) ;
// 	strncpy (s, "abcd", a - b) ;
// 	return 1/(a - c) ;
// }

int main() {
  int a, b, c;
  klee_make_symbolic(&a, sizeof(a), "a");
  klee_make_symbolic(&b, sizeof(b), "b");
  klee_make_symbolic(&c, sizeof(c), "c");
  return get_branch(a, b, c);
} 
