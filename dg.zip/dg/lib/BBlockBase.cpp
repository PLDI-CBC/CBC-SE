#include "dg/BBlockBase.h"

namespace dg {

unsigned ElemId::idcnt = 0;

}
