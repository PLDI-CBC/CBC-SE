#ifndef CALLRETURNNODE_H
#define CALLRETURNNODE_H

#include "Node.h"

class CallReturnNode : public Node {
  public:
    CallReturnNode();
};

#endif // CALLRETURNNODE_H
