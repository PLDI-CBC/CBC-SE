int get_int(int a) { return a; }
