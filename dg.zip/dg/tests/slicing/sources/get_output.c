#include <stdio.h>

FILE *get_output(void) { return stdout; }
