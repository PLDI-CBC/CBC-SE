int *ptr(int *p) { return p; }
