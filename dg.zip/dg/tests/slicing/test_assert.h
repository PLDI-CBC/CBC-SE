void test_assert(int cond);
