# -*- coding:utf-8 -*-
 
import os
import shutil
import re
import sys

experiment_dst1 = "/home/benchmarks/SIR"
experiment_dst2 = "/home/benchmarks/CVE"
experiment_dst3 = "/home/benchmarks/Coreutils"


if __name__ == "__main__":
    
    # 1. do the SIR experimrnt
    os.chdir(experiment_dst1)
    if len(sys.argv) > 1:
        if sys.argv[1] == 'clean':
            os.system('python3 init.py clean')
    else:
        os.system('python3 init.py')
    
    # 2. do the CVE experimrnt
    os.chdir(experiment_dst2)
    if len(sys.argv) > 1:
        if sys.argv[1] == 'clean':
            os.system('python3 init.py clean')
    else:
        os.system('python3 init.py')
    
    # 3. do the Coreutils experimrnt
    os.chdir(experiment_dst3)
    if len(sys.argv) > 1:
        os.system('python3 init.py clean')
    else:
        os.system('python3 init.py')

        

