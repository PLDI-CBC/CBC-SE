# -*- coding:utf-8 -*-
 
import os
import shutil
import re
import sys
import csv
import pandas as pd

benchmarks = ["printtokens", "printtokens2", "replace", "schedule", "schedule2", "tcas"]

src_path = "/home/benchmarks/SIR/"

KLEE_build = "/home/KLEE/klee_build/bin/"
DGSE_build = "/home/DGSE/klee_build/bin/"
CBC_build = "/home/CBC/klee_build/bin/"

KLEE_stats = "/home/KLEE/klee_build/bin/klee-stats"
DGSE_stats = "/home/DGSE/klee_build/bin/klee-stats"
CBC_stats  = "/home/CBC/klee_build/bin/klee-stats"

KLEE_dst_1 = "/home/results/SIR/KLEE/param_1/"
KLEE_dst_2 = "/home/results/SIR/KLEE/param_2/"

DGSE_dst_1 = "/home/results/SIR/DGSE/param_1/"
DGSE_dst_2 = "/home/results/SIR/DGSE/param_2/"

CBC_dst_1 = "/home/results/SIR/CBC/param_1/"
CBC_dst_2 = "/home/results/SIR/CBC/param_2/"

KLEE_analyze_csv_1 = "/home/benchmarks/SIR/KLEE_analyze_1.csv"
KLEE_analyze_csv_2 = "/home/benchmarks/SIR/KLEE_analyze_2.csv"

DGSE_analyze_csv_1 = "/home/benchmarks/SIR/DGSE_analyze_1.csv"
DGSE_analyze_csv_2 = "/home/benchmarks/SIR/DGSE_analyze_2.csv"

CBC_analyze_csv_1 = "/home/benchmarks/SIR/CBC_analyze_1.csv"
CBC_analyze_csv_2 = "/home/benchmarks/SIR/CBC_analyze_2.csv"

files = [
    "CBC_analyze_1.csv", "DGSE_analyze_1.csv", "KLEE_analyze_1.csv",
    "CBC_analyze_2.csv", "DGSE_analyze_2.csv", "KLEE_analyze_2.csv"
]

final_analyze_csv = "/home/benchmarks/SIR/SIR_analyze.csv"
 
def handel_KLEE_1(srcpath):
    os.chdir(srcpath)
    for root, dirs, files in os.walk(srcpath, True):
        for dir in dirs:
            print('     ----------Handling ' + dir + '----------')
            subdir = srcpath + dir
            os.chdir(subdir)
            for s_root, s_dirs, s_files in os.walk(subdir, True):
                for name in s_files:
                    if name.endswith('bc'):
                        if name.startswith('print_tokens_1'):
                            os.system(KLEE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + KLEE_dst_1 + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                                                   --sym-stdin 4 > ' + KLEE_dst_1 + 'klee_' + dir + '.log 2>&1')
                        elif name.startswith('print_tokens_2'):
                            os.system(KLEE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + KLEE_dst_1 + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                                                   --sym-stdin 4 > ' + KLEE_dst_1 + 'klee_' + dir + '.log 2>&1')
                        elif name.startswith('replace'):
                            os.system(KLEE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + KLEE_dst_1 + dir + ' ' +  name  + ' --sym-args 0 2 3 \
                                                   --sym-stdin 1 > ' + KLEE_dst_1 + 'klee_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_1'):
                            os.system(KLEE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + KLEE_dst_1 + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                                                   --sym-stdin 4 > ' + KLEE_dst_1 + 'klee_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_2'):
                            os.system(KLEE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + KLEE_dst_1 + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                                                   --sym-stdin 4 > ' + KLEE_dst_1 + 'klee_' + dir + '.log 2>&1')
                        else:
                            os.system(KLEE_build + 'klee --search=dfs --max-time=7200 --output-dir=' + KLEE_dst_1 + dir + ' ' + name + ' > '
                                                   + KLEE_dst_1 + 'klee_' + dir + '.log 2>&1')
            os.chdir('../')

def handel_KLEE_2(srcpath):
    os.chdir(srcpath)
    for root, dirs, files in os.walk(srcpath, True):
        for dir in dirs:
            print('     ----------Handling ' + dir + '----------')
            subdir = srcpath + dir
            os.chdir(subdir)
            for s_root, s_dirs, s_files in os.walk(subdir, True):
                for name in s_files:
                    if name.endswith('bc'):
                        if name.startswith('print_tokens_1'):
                            os.system(KLEE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + KLEE_dst_2 + dir + ' ' +  name  + ' --sym-args 0 4 2 \
                                                   --sym-stdin 8 > ' + KLEE_dst_2 + 'klee_' + dir + '.log 2>&1')
                        elif name.startswith('print_tokens_2'):
                            os.system(KLEE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + KLEE_dst_2 + dir + ' ' +  name  + ' --sym-args 0 4 2 \
                                                   --sym-stdin 8 > ' + KLEE_dst_2 + 'klee_' + dir + '.log 2>&1')
                        elif name.startswith('replace'):
                            os.system(KLEE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + KLEE_dst_2 + dir + ' ' +  name  + ' --sym-args 0 2 6 \
                                                   --sym-stdin 2 > ' + KLEE_dst_2 + 'klee_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_1'):
                            os.system(KLEE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + KLEE_dst_2 + dir + ' ' +  name  + ' --sym-args 0 4 2 \
                                                   --sym-stdin 8 > ' + KLEE_dst_2 + 'klee_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_2'):
                            os.system(KLEE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + KLEE_dst_2 + dir + ' ' +  name  + ' --sym-args 0 4 2 \
                                                   --sym-stdin 8 > ' + KLEE_dst_2 + 'klee_' + dir + '.log 2>&1')
                        else:
                            continue
            os.chdir('../')

def handel_DGSE_1(srcpath):
    os.chdir(srcpath)
    for root, dirs, files in os.walk(srcpath, True):
        for dir in dirs:
            print('     ----------Handling ' + dir + '----------')
            subdir = srcpath + dir
            os.chdir(subdir)
            for s_root, s_dirs, s_files in os.walk(subdir, True):
                for name in s_files:
                    if name.endswith('bc'):
                        if name.startswith('print_tokens_1'):
                            continue
                            # this program build failed
                            # os.system(DGSE_build + 'klee --search=dfs --max-time=3600 --libc=uclibc --posix-runtime --write-no-tests \
                            #                        --output-dir=' + DGSE_dst + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                            #                        --sym-stdin 4 > ' + DGSE_dst + 'DGSE_' + dir + '.log 2>&1')
                        if name.startswith('print_tokens_2'):
                            os.system(DGSE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + DGSE_dst_1 + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                                                   --sym-stdin 4 > ' + DGSE_dst_1 + 'DGSE_' + dir + '.log 2>&1')
                        elif name.startswith('replace'):
                            continue
                            # this program build failed
                            # os.system(DGSE_build + 'klee --search=dfs --max-time=3600 --libc=uclibc --posix-runtime --write-no-tests \
                            #                        --output-dir=' + DGSE_dst + dir + ' ' +  name  + ' --sym-args 0 2 3 \
                            #                        --sym-stdin 1 > ' + DGSE_dst + 'DGSE_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_1'):
                            os.system(DGSE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + DGSE_dst_1 + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                                                   --sym-stdin 4 > ' + DGSE_dst_1 + 'DGSE_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_2'):
                            os.system(DGSE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + DGSE_dst_1 + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                                                   --sym-stdin 4 > ' + DGSE_dst_1 + 'DGSE_' + dir + '.log 2>&1')
                        else:
                            os.system(DGSE_build + 'klee --search=dfs --max-time=7200 --output-dir=' + DGSE_dst_1 + dir + ' ' + name + ' > '
                                                   + DGSE_dst_1 + 'DGSE_' + dir + '.log 2>&1')
            os.chdir('../')

def handel_DGSE_2(srcpath):
    os.chdir(srcpath)
    for root, dirs, files in os.walk(srcpath, True):
        for dir in dirs:
            print('     ----------Handling ' + dir + '----------')
            subdir = srcpath + dir
            os.chdir(subdir)
            for s_root, s_dirs, s_files in os.walk(subdir, True):
                for name in s_files:
                    if name.endswith('bc'):
                        if name.startswith('print_tokens_1'):
                            continue
                        # this program build failed
                        #     os.system(DGSE_build + 'klee --search=dfs --max-time=3600 --libc=uclibc --posix-runtime --write-no-tests \
                        #                            --output-dir=' + DGSE_dst + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                        #                            --sym-stdin 4 > ' + DGSE_dst + 'DGSE_' + dir + '.log 2>&1')
                        if name.startswith('print_tokens_2'):
                            os.system(DGSE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + DGSE_dst_2 + dir + ' ' +  name  + ' --sym-args 0 4 2 \
                                                   --sym-stdin 8 > ' + DGSE_dst_2 + 'DGSE_' + dir + '.log 2>&1')
                        elif name.startswith('replace'):
                            continue
                        # this program build failed
                        #     os.system(DGSE_build + 'klee --search=dfs --max-time=3600 --libc=uclibc --posix-runtime --write-no-tests \
                        #                            --output-dir=' + DGSE_dst + dir + ' ' +  name  + ' --sym-args 0 2 3 \
                        #                            --sym-stdin 1 > ' + DGSE_dst + 'DGSE_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_1'):
                            os.system(DGSE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + DGSE_dst_2 + dir + ' ' +  name  + ' --sym-args 0 4 2 \
                                                   --sym-stdin 8 > ' + DGSE_dst_2 + 'DGSE_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_2'):
                            os.system(DGSE_build + 'klee --search=dfs --max-time=7200 --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + DGSE_dst_2 + dir + ' ' +  name  + ' --sym-args 0 4 2 \
                                                   --sym-stdin 8 > ' + DGSE_dst_2 + 'DGSE_' + dir + '.log 2>&1')
                        else:
                            continue
            os.chdir('../')

def handel_CBC_1(srcpath):
    os.chdir(srcpath)
    for root, dirs, files in os.walk(srcpath, True):
        for dir in dirs:
            print('     ----------Handling ' + dir + '----------')
            subdir = srcpath + dir
            os.chdir(subdir)
            for s_root, s_dirs, s_files in os.walk(subdir, True):
                for name in s_files:
                    if name.endswith('bc'):
                        if name.startswith('print_tokens_1'):
                            os.system(CBC_build + 'klee --search=dfs --max-time=7200 --reverse-limit=4 --states-limit=50 \
                                                   --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + CBC_dst_1 + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                                                   --sym-stdin 4 > ' + CBC_dst_1 + 'CBC_' + dir + '.log 2>&1')
                        elif name.startswith('print_tokens_2'):
                            os.system(CBC_build + 'klee --search=dfs --max-time=7200 --reverse-limit=4 --states-limit=50 \
                                                   --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + CBC_dst_1 + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                                                   --sym-stdin 4 > ' + CBC_dst_1 + 'CBC_' + dir + '.log 2>&1')
                        elif name.startswith('replace'):
                            os.system(CBC_build + 'klee --search=dfs --max-time=7200 --reverse-limit=4 --states-limit=50 \
                                                   --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + CBC_dst_1 + dir + ' ' +  name  + ' --sym-args 0 2 3 \
                                                   --sym-stdin 1 > ' + CBC_dst_1 + 'CBC_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_1'):
                            os.system(CBC_build + 'klee --search=dfs --max-time=7200 --reverse-limit=4 --states-limit=50 \
                                                   --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + CBC_dst_1 + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                                                   --sym-stdin 4 > ' + CBC_dst_1 + 'CBC_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_2'):
                            os.system(CBC_build + 'klee --search=dfs --max-time=7200 --reverse-limit=4 --states-limit=50 \
                                                   --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + CBC_dst_1 + dir + ' ' +  name  + ' --sym-args 0 4 1 \
                                                   --sym-stdin 4 > ' + CBC_dst_1 + 'CBC_' + dir + '.log 2>&1')
                        else:
                            os.system(CBC_build + 'klee --search=dfs --max-time=7200 --output-dir=' + CBC_dst_1 + dir + ' ' + name + ' > '
                                                   + CBC_dst_1 + 'CBC_' + dir + '.log 2>&1')
            os.chdir('../')

def handel_CBC_2(srcpath):
    os.chdir(srcpath)
    for root, dirs, files in os.walk(srcpath, True):
        for dir in dirs:
            print('     ----------Handling ' + dir + '----------')
            subdir = srcpath + dir
            os.chdir(subdir)
            for s_root, s_dirs, s_files in os.walk(subdir, True):
                for name in s_files:
                    if name.endswith('bc'):
                        if name.startswith('print_tokens_1'):
                            os.system(CBC_build + 'klee  --search=dfs --max-time=7200 --reverse-limit=4 --states-limit=50 \
                                                   --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + CBC_dst_2 + dir + ' ' +  name  + ' --sym-args 0 4 2 \
                                                   --sym-stdin 8 > ' + CBC_dst_2 + 'CBC_' + dir + '.log 2>&1')
                        elif name.startswith('print_tokens_2'):
                            os.system(CBC_build + 'klee --search=dfs --max-time=7200 --reverse-limit=4 --states-limit=50 \
                                                   --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + CBC_dst_2 + dir + ' ' +  name  + ' --sym-args 0 4 2 \
                                                   --sym-stdin 8 > ' + CBC_dst_2 + 'CBC_' + dir + '.log 2>&1')
                        elif name.startswith('replace'):
                            os.system(CBC_build + 'klee --search=dfs --max-time=7200 --reverse-limit=4 --states-limit=50 \
                                                   --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + CBC_dst_2 + dir + ' ' +  name  + ' --sym-args 0 2 6 \
                                                   --sym-stdin 2 > ' + CBC_dst_2 + 'CBC_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_1'):
                            os.system(CBC_build + 'klee --search=dfs --max-time=7200 --reverse-limit=4 --states-limit=50 \
                                                   --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + CBC_dst_2 + dir + ' ' +  name  + ' --sym-args 0 4 2 \
                                                   --sym-stdin 8 > ' + CBC_dst_2 + 'CBC_' + dir + '.log 2>&1')
                        elif name.startswith('schedule_2'):
                            os.system(CBC_build + 'klee --search=dfs --max-time=7200 --reverse-limit=4 --states-limit=50 \
                                                   --libc=uclibc --posix-runtime --write-no-tests \
                                                   --output-dir=' + CBC_dst_2 + dir + ' ' +  name  + ' --sym-args 0 4 2 \
                                                   --sym-stdin 8 > ' + CBC_dst_2 + 'CBC_' + dir + '.log 2>&1')
                        else:
                            continue
            os.chdir('../')

def analyze_data(srcpath, dstpath, tool):
    os.chdir(srcpath)
    for root, dirs, files in os.walk(srcpath, True):
        for name in dirs:
            if tool is "KLEE":
                os.system(KLEE_stats + ' --table-format=plain  --print-more ' + name + ' > ' + name + '.txt')
            elif tool is "DGSE":
                os.system(DGSE_stats + ' --table-format=plain  --print-more ' + name + ' > ' + name + '.txt')
            else:
                os.system(CBC_stats + ' --table-format=plain  --print-more ' + name + ' > ' + name + '.txt')
    data = []
    flag = 0
    dlag = 0
    for root, dirs, files in os.walk(srcpath, True):
        for file in files:
            temp = []
            if file.endswith ('txt'):
                if file.startswith('warning') or file.startswith('messages'):
                    continue
                else:
                    subname = file.split(".")[0]
                with open(srcpath + file,'r') as f:
                    for line in f:
                        if "Path" in line:
                            continue
                        results = list(line.split())
                        temp.append(results[0])
                        temp.append(results[1])
                        temp.append(results[2])
                subdir = srcpath + subname
                os.chdir(subdir)
                with open('info','r') as f:
                    for line in f:
                        if line.startswith("Analysis:"):
                            flag = 1
                            arr = list(line.strip().split(' '))
                            temp.append(arr[1])
                        if line.startswith("Divede:"):
                            flag = 1
                            dlag = 1
                            arr = list(line.strip().split(' '))
                            temp.append(arr[1])
                        if line.startswith("Check:"):
                            flag = 1
                            arr = list(line.strip().split(' '))
                            temp.append(arr[1])
                        elif line.startswith("KLEE: done: completed"):
                            arr = list(line.strip().split(' '))
                            temp.append(arr[5])
                        else:
                            continue
                os.chdir("../")
            if len(temp) > 0 :
                data.append(temp) 
 
    f = open(dstpath,'w',encoding='utf-8',newline='')
    csv_writer = csv.writer(f)
    if flag == 0:
        csv_writer.writerow(["benchMark", "Instrs", "Time(s)", "Completed"])
    else:
        if dlag == 1:
            csv_writer.writerow(["benchMark", "Instrs", "Time(s)", "Analysis(s)", "Divide(s)", "Check(s)", "Completed"])
        else:
            csv_writer.writerow(["benchMark", "Instrs", "Time(s)", "Analysis(s)", "Check(s)", "Completed"])
    csv_writer.writerows(data)
    f.close

def merge_data(srcpath):
    os.chdir(srcpath)
    merged_df = pd.DataFrame(columns=['Programs', 'KLEE_Instructions', 'DGSE_Instructions', 'CBC_Instructions',
                                  'DGSE_Instructions/KLEE_Instructions', 'CBC_Instructions/KLEE_Instructions',
                                  'KLEE_Paths', 'DGSE_Paths', 'CBC_Paths', 'DGSE_Paths/KLEE_Paths',
                                  'CBC_Paths/KLEE_Paths', 'KLEE_Time', 'DGSE_Time', 'CBC_Time',
                                  'KLEE_Time/DGSE_Time', 'KLEE_Time/CBC_Time'])
    row_names = ['schedule_1', 'schedule_2', 'printtokens2_1', 'printtokens2_2',
                 'replace_1', 'replace_2', 'printtokens_1', 'printtokens_2',
                 'schedule2_1', 'schedule2_2', 'tcas_1']
    prefix_mapping = {'CBC': 'CBC', 'DGSE': 'DGSE', 'KLEE': 'KLEE'}
    suffix_mapping = {'1': '_1', '2': '_2'}
    # Add rows for each program
    for program_row_name in row_names:
        merged_df = merged_df.append({'Programs': program_row_name}, ignore_index=True)
    for file in files:
        prefix = file.split('_')[0]
        suffix = file.split('_')[-1].split('.')[0]
        df = pd.read_csv(file)
        for index, row in df.iterrows():
            program_name = row['benchMark']
            program_row_name = program_name + (suffix_mapping[suffix] if suffix != 'csv' else '')
            instrs_col = f'{prefix}_Instructions'
            paths_col = f'{prefix}_Paths'
            time_col = f'{prefix}_Time'
            instrs = row['Instrs']
            paths = row['Completed']
            time = row['Time(s)']
            try:
                merged_df.loc[merged_df['Programs'] == program_row_name, instrs_col] = instrs
                merged_df.loc[merged_df['Programs'] == program_row_name, paths_col] = paths
                merged_df.loc[merged_df['Programs'] == program_row_name, time_col] = time
            except IndexError:
                pass
    # Fill NaN values with 0
    merged_df.fillna(0, inplace=True)
    # Calculate ratios with two decimal places
    merged_df['DGSE_Instructions/KLEE_Instructions'] = round(merged_df['DGSE_Instructions'] / merged_df['KLEE_Instructions'], 2)
    merged_df['CBC_Instructions/KLEE_Instructions'] = round(merged_df['CBC_Instructions'] / merged_df['KLEE_Instructions'], 2)
    merged_df['DGSE_Paths/KLEE_Paths'] = round(merged_df['DGSE_Paths'] / merged_df['KLEE_Paths'], 2)
    merged_df['CBC_Paths/KLEE_Paths'] = round(merged_df['CBC_Paths'] / merged_df['KLEE_Paths'], 2)
    merged_df['KLEE_Time/DGSE_Time'] = round(merged_df['KLEE_Time'] / merged_df['DGSE_Time'], 2)
    merged_df['KLEE_Time/CBC_Time'] = round(merged_df['KLEE_Time'] / merged_df['CBC_Time'], 2)
    merged_df.to_csv(final_analyze_csv, index=False)

def make_clean(dstpath):
    os.chdir(dstpath)
    os.system('rm -rf *')

if __name__ == "__main__":
    print("%%  Doing the efficacy verfication experiment:  %%")

    print('~~~~~~~~~~~~~~~~~~~~~ Handling KLEE ~~~~~~~~~~~~~~~~~~~~~')
    handel_KLEE_1(src_path)
    handel_KLEE_2(src_path)
    print('~~~~~~~~~~~~~~~~~~~~~ Handling DGSE ~~~~~~~~~~~~~~~~~~~~~')
    handel_DGSE_1(src_path)
    handel_DGSE_2(src_path)
    print('~~~~~~~~~~~~~~~~~~~~~ Handling CBC ~~~~~~~~~~~~~~~~~~~~~')
    handel_CBC_1(src_path)
    handel_CBC_2(src_path)

    print('~~~~~~~~~~~~~~~~~~~~~ Analyzing KLEE ~~~~~~~~~~~~~~~~~~~~~')
    analyze_data(KLEE_dst_1, KLEE_analyze_csv_1, "KLEE")
    analyze_data(KLEE_dst_2, KLEE_analyze_csv_2, "KLEE")
    print('~~~~~~~~~~~~~~~~~~~~~ Analyzing DGSE ~~~~~~~~~~~~~~~~~~~~~')
    analyze_data(DGSE_dst_1, DGSE_analyze_csv_1, "DGSE")
    analyze_data(DGSE_dst_2, DGSE_analyze_csv_2, "DGSE")
    print('~~~~~~~~~~~~~~~~~~~~~ Analyzing CBC ~~~~~~~~~~~~~~~~~~~~~')
    analyze_data(CBC_dst_1, CBC_analyze_csv_1, "CBC")
    analyze_data(CBC_dst_2, CBC_analyze_csv_2, "CBC")

    print('~~~~~~~~~~~~~~~~~~~~~ Merging data ~~~~~~~~~~~~~~~~~~~~~')
    merge_data(src_path)

    if len(sys.argv) > 1:
        make_clean(KLEE_dst_1)
        make_clean(KLEE_dst_2)
        make_clean(DGSE_dst_1)
        make_clean(DGSE_dst_2)
        make_clean(CBC_dst_1)
        make_clean(CBC_dst_2)

