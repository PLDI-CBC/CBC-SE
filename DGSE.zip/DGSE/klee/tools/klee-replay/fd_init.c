#include "../../runtime/POSIX/fd_init.c"
