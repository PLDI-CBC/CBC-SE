# -*- coding:utf-8 -*-

import os
import shutil
import re
import sys
import csv

import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

import xlwings as xw
from sklearn import linear_model

import threading

# get CBC_DIR
cbc_dir = os.environ.get('CBC_DIR')

if not cbc_dir:
    print("Error: CBC_DIR environment variable is not set.")
    exit(1)

# Define the paths
src_path_table3 = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Table3")
src_path_fig5 = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Fig5")
src_path_fig6 = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Fig6")

KLEE_build = os.path.join(cbc_dir, "KLEE", "klee_build", "bin", "")
CBC_build = os.path.join(cbc_dir, "CBC", "klee_build", "bin", "")

KLEE_stats = os.path.join(cbc_dir, "KLEE", "klee_build", "bin", "klee-stats")

KLEE_dst_table3 = os.path.join(cbc_dir, "results", "Coreutils", "KLEE", "Table3", "")
CBC_dst_table3 = os.path.join(cbc_dir, "results", "Coreutils", "CBC", "Table3", "")

KLEE_dst_fig5_2h = os.path.join(cbc_dir, "results", "Coreutils", "KLEE", "Fig5", "2h", "")
CBC_dst_fig5_2h = os.path.join(cbc_dir, "results", "Coreutils", "CBC", "Fig5", "2h", "")

KLEE_dst_fig5_4h = os.path.join(cbc_dir, "results", "Coreutils", "KLEE", "Fig5", "4h", "")
CBC_dst_fig5_4h = os.path.join(cbc_dir, "results", "Coreutils", "CBC", "Fig5", "4h", "")

KLEE_dst_fig6 = os.path.join(cbc_dir, "results", "Coreutils", "KLEE", "Fig6", "")
CBC_dst_fig6 = os.path.join(cbc_dir, "results", "Coreutils", "CBC", "Fig6", "")

KLEE_analyze_csv_table3 = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Table3", "csvDir", "KLEE_analyze_table3.csv")
CBC_analyze_csv_table3 = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Table3", "csvDir", "CBC_analyze_table3.csv")

coreutils_csv_table3 = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Table3", "csvDir", "analyze_table3.csv")
coreutils_csv_table4 = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Table3", "csvDir", "overhead_table4.csv")

KLEE_analyze_csv_fig5_2h = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Fig5", "csvDir", "KLEE_analyze_fig5_2h.csv")
CBC_analyze_csv_fig5_2h = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Fig5", "csvDir", "CBC_analyze_fig5_2h.csv")

KLEE_analyze_csv_fig5_4h = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Fig5", "csvDir", "KLEE_analyze_fig5_4h.csv")
CBC_analyze_csv_fig5_4h = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Fig5", "csvDir", "CBC_analyze_fig5_4h.csv")

KLEE_analyze_csv_fig6 = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Fig6", "csvDir", "")

analyze_pic_2h = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Fig5", "picDir", "bcov_2h.png")
analyze_pic_4h = os.path.join(cbc_dir, "benchmarks", "Coreutils", "Fig5", "picDir", "bcov_4h.png")


file_list = ["uptime", "dirname", "od", "getlimits", "cut",  "runcon", "pinky", "users", "stdbuf", "basename", "unlink"]

def handel_KLEE(srcpath, dstpath, timeout):
    timeout = 7200 if timeout == "2h" else 14400
    os.chdir(srcpath)
    for root, dirs, files in os.walk(srcpath, True):
        dirs[:] = []
        for name in files:
            if name.split('.')[-1] != "bc":
                continue
            subname = flag = name.split(".")[0]
            print('**************** Handling ' + subname + '****************')
            os.system(KLEE_build + 'klee --max-time=' + str(timeout) + ' --search=random-path --max-memory=4000 \
                --libc=uclibc --posix-runtime --write-no-tests \
                --output-dir=' + dstpath + 'klee-out-' + subname + 
                ' ' + subname + '.bc'  + ' --sym-args 0 1 3 --sym-args 0 2 2 --sym-files 1 1 --sym-stdin 8 > ' + dstpath + 'run-KLEE-'
                + subname + '.log 2>&1')

def handel_CBC(srcpath, dstpath, timeout, exenum):
    timeout = 7200 if timeout == "2h" else 14400
    os.chdir(srcpath)
    for root, dirs, files in os.walk(srcpath, True):
        dirs[:] = []
        for name in files:
            if name.split('.')[-1] != "bc":
                continue
            subname = name.split(".")[0]
            if subname in file_list or exenum == "exe2" or exenum == "exe3":
                print('**************** Handling ' + subname + '****************')
                os.system(CBC_build + 'klee --max-time=' + str(timeout) + ' --reverse-limit=50 --states-limit=5000 --search=random-path --max-memory=4000 \
                    --libc=uclibc --posix-runtime --write-no-tests \
                    --output-dir=' + dstpath + 'klee-out-' + subname + 
                    ' ' + subname + '.bc'  + ' --sym-args 0 1 3 --sym-args 0 2 2 --sym-files 1 1 --sym-stdin 8 > ' + dstpath + 'run-CBC-'
                    + subname + '.log 2>&1')
            else:
                print('**************** Handling ' + subname + '****************')
                os.system(CBC_build + 'klee --max-time=' + str(timeout) + '  --reverse-limit=50 --states-limit=50 --search=random-path --max-memory=4000 \
                    --libc=uclibc --posix-runtime --write-no-tests \
                    --output-dir=' + dstpath + 'klee-out-' + subname + 
                    ' ' + subname + '.bc'  + ' --sym-args 0 1 3 --sym-args 0 2 2 --sym-files 1 1 --sym-stdin 8 > ' + dstpath + 'run-CBC-'
                    + subname + '.log 2>&1')

def analyze_data(srcpath, dstpath):
    os.chdir(srcpath)
    for root, dirs, files in os.walk(srcpath, True):
        for name in dirs:
            subname = name.split(".")[0]
            if name.startswith('klee'):
                os.system(KLEE_stats + ' --table-format=plain  --print-more ' + name + ' > ' + subname + '.txt')
    data = []
    flag = 0
    for root, dirs, files in os.walk(srcpath, True):
        for file in files:
            temp = []
            if file.endswith ('txt') and file.startswith('klee'):
                subname = file.split(".")[0]
                with open(srcpath + file,'r') as f:
                    for line in f:
                        if line.startswith('klee'):
                            results = list(line.split())
                            temp.append(results[0])
                            temp.append(results[1])
                            temp.append(results[2])
                            temp.append(results[3])
                            temp.append(results[4])
                            temp.append(results[9])
                subdir = srcpath + subname
                os.chdir(subdir)
                with open('info','r') as f:
                    for line in f:
                        if line.startswith("DG_build"):
                            flag = 1
                            arr = list(line.strip().split(' '))
                            temp.append(arr[1])
                        if line.startswith("Analysis"):
                            flag = 1
                            arr = list(line.strip().split(' '))
                            temp.append(arr[1])
                        if line.startswith("Divede"):
                            flag = 1
                            arr = list(line.strip().split(' '))
                            temp.append(arr[1])
                        if line.startswith("Check"):
                            flag = 1
                            arr = list(line.strip().split(' '))
                            temp.append(arr[1])
                        elif line.startswith("KLEE: done: redundant"):
                            flag = 1
                            arr = list(line.strip().split(' '))
                            temp.append(arr[5])
                        elif line.startswith("KLEE: done: completed"):
                            arr = list(line.strip().split(' '))
                            temp.append(arr[5])
                        else:
                            continue
                os.chdir("../")
            if len(temp) > 0 :
                data.append(temp) 
 
    f = open(dstpath,'w',encoding='utf-8',newline='')
    csv_writer = csv.writer(f)
    if flag == 1:
        csv_writer.writerow(["benchMark", "Instrs", "Time(s)", "ICov(%)", "BCov(%)", "Mem(MB)", "DG_build", "Anlysis(s)", "Divide(s)", "Check(s)", "DeletedPath", "Completed"])
    else:
        csv_writer.writerow(["benchMark", "Instrs", "Time(s)", "ICov(%)", "BCov(%)", "Mem(MB)", "Completed"])
    csv_writer.writerows(data)
    f.close

def handle_csv(srcpath, dstpath, model):
    os.chdir(dstpath)
    for root, dirs, files in os.walk(dstpath, True):
        for dir in dirs:
            file = dir.split('-')[-1]
            output = srcpath + file + "_" + model + ".csv"
            print(output)
            os.system('sqlite3 ' + dstpath + '/klee-out-' + file + '/run.stats "SELECT (WallTime / (1000000 * 3600)), CoveredInstructions, 100 * (2 * FullBranches + \
                          PartialBranches) / (2 * NumBranches), MallocUsage FROM stats ORDER BY WallTime" >' + output)
            with open(output, 'r+') as f:
                content = f.read()       
                f.seek(0, 0)
                f.write('Time,Instrs,Bcov,Mem\n'+content)
            f = open(output, 'r+')
            datalines = f.readlines()
            f.close()
            f = open(output, 'w+')
            for eachline in datalines:
                a = eachline.replace('|', ',')
                if a[0] > '2' and a[1] > '1' and a[0] != 'T':
                    continue
                if a[0] < '2' or a[0] == 'T':
                    f.writelines(a)

def draw_pic(src_path, dst_path):
    for root, dirs, files in os.walk(src_path, topdown=True):
        dirs[:] = []
        for f in files:
            if f.split('.')[-1] != "bc":
                continue
            file = f.split('.')[0]
            KLEE_dst = dst_path + file + "_KLEE.csv" 
            CBC_dst = dst_path + file + "_CBC.csv" 
            plt.rcParams['font.sans-serif'] = ['SimHei']  
            plt.rcParams['axes.unicode_minus'] = False   

            df = pd.read_csv(CBC_dst, encoding='utf-8', keep_default_na=False)  
            df2 = pd.read_csv(KLEE_dst, encoding='utf-8', keep_default_na=False)

            fig = plt.figure(figsize=(15,9), dpi=100)
            ax = fig.add_subplot(111)

            ax.plot(df['Time'],df['Bcov'],color='r', linewidth=2.0, label='CBC')
            ax.plot(df2['Time'],df2['Bcov'],color='g', linestyle='--', linewidth=2.0, label='KLEE')

            # plt.legend(loc = 0, prop = {'size':20})
            plt.rc('legend', fontsize=16)

            plt.yticks(fontproperties = 'Times New Roman', size = 14)
            plt.xticks(fontproperties = 'Times New Roman', size = 14)   

            plt.xlabel('Time(hours)', fontsize=20)    
            plt.ylabel("Bcov(%)", fontsize=20)         
            ax.legend()                           
            plt.title(file, fontsize=25, color='black', pad=20)

            plt.savefig(src_path + "/picDir/" + file + "_Bcov.png")
            plt.show()
            plt.close()

def draw_point(src_path, klee_dst, cbc_dst):
    KLEE_df = pd.read_csv(klee_dst)
    CBC_df  = pd.read_csv(cbc_dst)
    # bcov
    figure_bcov = plt.figure()    
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    x_bcov = range(0, 35)
    y_bcov = x_bcov
    plt.plot(x_bcov, y_bcov, "--", linewidth = 0.8)
    x_bcov = KLEE_df['BCov(%)']
    y_bcov = CBC_df['BCov(%)']
    plt.scatter(x_bcov, y_bcov, s = 50, c = 'y', marker = '^', edgecolor = 'black')
    plt.xlabel('KLEE Bcov(%)', fontdict = {'family' : 'Microsoft YaHei', 'color' : 'black', 'size' : 10}, labelpad = 10)
    plt.ylabel('CBC Bcov(%)', fontdict = {'family' : 'Microsoft YaHei', 'color' : 'black', 'size' : 10}, labelpad = 10)
    plt.savefig(src_path)

def process_time(time_str):
    if time_str:
        time_values = time_str.split('s')
        time_value = float(time_values[0])
    else:
        time_value = float(0)
    return time_value

def merge_data(klee_csv, cbc_csv):
    cbc_df = pd.read_csv(cbc_csv, engine='python')
    klee_df = pd.read_csv(klee_csv, engine='python')
    cbc_df.rename(columns={'benchMark': 'Programs', 'Instrs': 'CBC_Instructions',
                           'Time(s)': 'CBC_Time', 'ICov(%)': 'CBC_ICov',
                           'BCov(%)': 'CBC_BCov', 'Mem(MB)': 'CBC_Mem',
                           'DG_build': 'CBC_DG_build', 'Anlysis(s)': 'CBC_Analysis',
                           'Divide(s)': 'CBC_Divide', 'Check(s)': 'CBC_Check',
                           'DeletedPath': 'CBC_DeletedPath', 'Completed': 'CBC_Completed'},
                  inplace=True)
    klee_df.rename(columns={'benchMark': 'Programs', 'Instrs': 'KLEE_Instructions',
                            'Time(s)': 'KLEE_Time', 'ICov(%)': 'KLEE_ICov',
                            'BCov(%)': 'KLEE_BCov', 'Mem(MB)': 'KLEE_Mem',
                            'Completed': 'KLEE_Completed'},
                   inplace=True)
    # generate table3
    merged_df_table3 = pd.DataFrame(columns=['Programs', 'KLEE_Instructions', 'KLEE_Paths', 'KLEE_Time',
                                       'CBC_Instructions', 'CBC_Paths', 'CBC_Time',
                                       'Instr ratio(%)', 'Path ratio(%)', 'Prune rate(%)', 'Speedup'])
    merged_df_table3['Programs'] = cbc_df['Programs']
    merged_df_table3['KLEE_Instructions'] = klee_df['KLEE_Instructions']
    merged_df_table3['KLEE_Paths'] = klee_df['KLEE_Completed']
    merged_df_table3['KLEE_Time'] = klee_df['KLEE_Time']
    merged_df_table3['CBC_Instructions'] = cbc_df['CBC_Instructions']
    merged_df_table3['CBC_Paths'] = cbc_df['CBC_Completed']
    merged_df_table3['CBC_Time'] = cbc_df['CBC_Time']
    merged_df_table3['Instr ratio(%)'] = ((klee_df['KLEE_Instructions'] - cbc_df['CBC_Instructions']) / klee_df['KLEE_Instructions']) * 100
    merged_df_table3['Instr ratio(%)'] = merged_df_table3['Instr ratio(%)'].round(2)
    merged_df_table3['Path ratio(%)'] = ((klee_df['KLEE_Completed'] - cbc_df['CBC_Completed']) / klee_df['KLEE_Completed']) * 100
    merged_df_table3['Path ratio(%)'] = merged_df_table3['Path ratio(%)'].round(2)
    merged_df_table3['Prune rate(%)'] = (cbc_df['CBC_DeletedPath'] / ( cbc_df['CBC_DeletedPath'] + cbc_df['CBC_Completed'])) * 100
    merged_df_table3['Prune rate(%)'] = merged_df_table3['Prune rate(%)'].round(2)
    merged_df_table3['Speedup'] = klee_df['KLEE_Time'] / cbc_df['CBC_Time']
    merged_df_table3['Speedup'] = merged_df_table3['Speedup'].round(2)
    merged_df_table3.to_csv(coreutils_csv_table3, index=False)

    # generate table4
    merged_df_table4 = pd.DataFrame(columns=['Programs', 'KLEE_Mem', 'CBC_Mem', 'CBC_SA',
                                       'CBC_PP', 'CBC_AT', '(SA+PP)/AT'])
    cbc_df['CBC_DG_build'] = cbc_df['CBC_DG_build'].apply(process_time)
    cbc_df['CBC_Analysis'] = cbc_df['CBC_Analysis'].apply(process_time)
    cbc_df['CBC_Divide']   = cbc_df['CBC_Divide'].apply(process_time)
    cbc_df['CBC_Check']    = cbc_df['CBC_Check'].apply(process_time)
    merged_df_table4['Programs'] = cbc_df['Programs']
    merged_df_table4['KLEE_Mem'] = klee_df['KLEE_Mem']
    merged_df_table4['CBC_Mem'] = cbc_df['CBC_Mem']
    merged_df_table4['CBC_SA'] = cbc_df['CBC_DG_build'] + cbc_df['CBC_Analysis']
    merged_df_table4['CBC_SA'] = merged_df_table4['CBC_SA'].round(2)
    merged_df_table4['CBC_PP'] = cbc_df['CBC_Divide'] + cbc_df['CBC_Check']
    merged_df_table4['CBC_PP'] = merged_df_table4['CBC_PP'].round(2)
    merged_df_table4['CBC_AT'] = cbc_df['CBC_Time']
    merged_df_table4['(SA+PP)/AT'] = (merged_df_table4['CBC_SA'].astype(float) + merged_df_table4['CBC_PP'].astype(float)) / merged_df_table4['CBC_AT'].astype(float)
    merged_df_table4['(SA+PP)/AT'] = merged_df_table4['(SA+PP)/AT'].round(2)
    merged_df_table4.to_csv(coreutils_csv_table4, index=False)

def make_clean(dstpath):
    os.chdir(dstpath)
    os.system('rm -rf *')

def exe_1():
    print("%%  Programs terminated normally without time out  %%")
    print('~~~~~~~~~~~~~~~~~~~~~ Handling KLEE ~~~~~~~~~~~~~~~~~~~~~')
    handel_KLEE(src_path_table3, KLEE_dst_table3, "2h")
    print('~~~~~~~~~~~~~~~~~~~~~ Handling CBC ~~~~~~~~~~~~~~~~~~~~~')
    handel_CBC(src_path_table3, CBC_dst_table3, "2h", "exe1")
    print('~~~~~~~~~~~~~~~~~~~~~ Analyzing KLEE ~~~~~~~~~~~~~~~~~~~~~')
    analyze_data(KLEE_dst_table3, KLEE_analyze_csv_table3)
    print('~~~~~~~~~~~~~~~~~~~~~ Analyzing CBC ~~~~~~~~~~~~~~~~~~~~~')
    analyze_data(CBC_dst_table3, CBC_analyze_csv_table3)
    print('~~~~~~~~~~~~~~~~~~~~~ Merge data ~~~~~~~~~~~~~~~~~~~~~')
    merge_data(KLEE_analyze_csv_table3, CBC_analyze_csv_table3)

def exe_2():
    print("%%  Programs time out  %%")
    print('~~~~~~~~~~~~~~~~~~~~~ Handling KLEE ~~~~~~~~~~~~~~~~~~~~~')
    handel_KLEE(src_path_fig5, KLEE_dst_fig5_2h, "2h")
    handel_KLEE(src_path_fig5, KLEE_dst_fig5_4h, "4h")
    print('~~~~~~~~~~~~~~~~~~~~~ Handling CBC  ~~~~~~~~~~~~~~~~~~~~~')
    handel_CBC(src_path_fig5, CBC_dst_fig5_2h, "2h", "exe2")
    handel_CBC(src_path_fig5, CBC_dst_fig5_4h, "4h", "exe2")
    print('~~~~~~~~~~~~~~~~~~~~~ Analyzing KLEE ~~~~~~~~~~~~~~~~~~~~~')
    analyze_data(KLEE_dst_fig5_2h, KLEE_analyze_csv_fig5_2h)
    analyze_data(KLEE_dst_fig5_4h, KLEE_analyze_csv_fig5_4h)
    print('~~~~~~~~~~~~~~~~~~~~~ Analyzing CBC ~~~~~~~~~~~~~~~~~~~~~')
    analyze_data(CBC_dst_fig5_2h, CBC_analyze_csv_fig5_2h)
    analyze_data(CBC_dst_fig5_4h, CBC_analyze_csv_fig5_4h)
    print('~~~~~~~~~~~~~~~~~~~~~ Analyzing data ~~~~~~~~~~~~~~~~~~~~~')
    draw_point(analyze_pic_2h, KLEE_analyze_csv_fig5_2h, CBC_analyze_csv_fig5_2h)
    draw_point(analyze_pic_4h, KLEE_analyze_csv_fig5_4h, CBC_analyze_csv_fig5_4h)

def exe_3():
    print("%%  Curve of branch coverage rate over time  %%")
    print('~~~~~~~~~~~~~~~~~~~~~ Handling KLEE ~~~~~~~~~~~~~~~~~~~~~')
    handel_KLEE(src_path_fig6, KLEE_dst_fig6, "2h")
    print('~~~~~~~~~~~~~~~~~~~~~ Handling CBC ~~~~~~~~~~~~~~~~~~~~~')
    handel_CBC(src_path_fig6, CBC_dst_fig6, "2h", "exe3")
    print('~~~~~~~~~~~~~~~~~~~~~ Analyzing data ~~~~~~~~~~~~~~~~~~~~~')
    handle_csv(KLEE_analyze_csv_fig6, KLEE_dst_fig6, "KLEE")
    handle_csv(KLEE_analyze_csv_fig6, CBC_dst_fig6, "CBC")
    draw_pic(src_path_fig6, KLEE_analyze_csv_fig6)

def clean_exe1():
    make_clean(KLEE_dst_table3)
    make_clean(CBC_dst_table3)

def clean_exe2():
    make_clean(KLEE_dst_fig5_2h)
    make_clean(KLEE_dst_fig5_4h)
    make_clean(CBC_dst_fig5_2h)
    make_clean(CBC_dst_fig5_4h)

def clean_exe3():
    make_clean(KLEE_dst_fig6)
    make_clean(CBC_dst_fig6)

if __name__ == "__main__":
    print("%%  Doing the Coreutils experiment:  %%")

    if len(sys.argv) == 1:
        clean_exe1()
        exe_1()
        clean_exe2()
        exe_2()
        clean_exe3()
        exe_3()

    elif len(sys.argv) == 2:
        command = sys.argv[1]
        if command == 'exe1':
            clean_exe1()
            exe_1()
        elif command == 'exe2':
            clean_exe2()
            exe_2()
        elif command == 'exe3':
            clean_exe3()
            exe_3()
        elif command == 'clean':
            clean_exe1()
            exe_1()
            clean_exe1()
            clean_exe2()
            exe_2()
            clean_exe2()
            clean_exe3()
            exe_3()
            clean_exe3()

    elif len(sys.argv) == 3:
        command = sys.argv[1]
        if command == "exe1":
            clean_exe1()
            exe_1()
            clean_exe1()
        elif command == "exe2":
            clean_exe2()
            exe_2()
            clean_exe2()
        elif command == "exe3":
            clean_exe3()
            exe_3()
            clean_exe3()
        else:
            print("Unknow command: ", command)
        

        