#!/bin/bash

CBC_DIR="$CBC_DIR"

# Parameters: 1- directory, 2- label
# Returns on STDOUT: label,coverage,dfs,random
print_single_result_time()
{
    paste -d ',' \
    <( echo "$2" ) \
    <( echo "$3" ) \
    <( grep Elapsed $1*/*-coverage$4/info | cut -d ' ' -f2 ) \
    <( grep Elapsed $1*/*-dfs$4/info | cut -d ' ' -f2 ) \
    <( grep Elapsed $1*/*-random$4/info | cut -d ' ' -f2 )
}

# Parameters: 1- directory, 2- label
# Returns on STDOUT: label,coverage,dfs,random
print_single_result_path()
{
    paste -d ',' \
    <( echo "$2" ) \
    <( echo "$3" ) \
    <( grep completed $1*/*-coverage$4/info | cut -d ' ' -f6 ) \
    <( grep completed $1*/*-dfs$4/info | cut -d ' ' -f6 ) \
    <( grep completed $1*/*-random$4/info | cut -d ' ' -f6 )
}

print_header()
{
    echo "BENCHMARK, EXPERIMENT,COVERAGE,DFS,RANDOM"
}

print_results()
{
    if [ -n "$3" ]
    then
        SUBBENCH="-$3"
    else
        SUBBENCH=""
    fi
    echo "===== Running on '$1$SUBBENCH' =====" >&2
    cd $2
    print_header
    print_single_result_time   "KLEE" "$1" "KLEE_times" $SUBBENCH
    print_single_result_path   "KLEE" "$1" "KLEE_paths" $SUBBENCH
    print_single_result_time   "CBC" "$1" "CBC_times" $SUBBENCH
    print_single_result_path   "CBC" "$1" "CBC_paths" $SUBBENCH
    cd ..
}


## MAIN
print_results CVE-2012-1569    $(CBC_DIR)/results/CVE/libtasn1/CVE-2012-1569   >   $(CBC_DIR)/benchmarks/CVE/CVE-2012-1569.csv   
print_results CVE-2014-3467_1  $(CBC_DIR)/results/CVE/libtasn1/CVE-2014-3467 1 >   $(CBC_DIR)/benchmarks/CVE/CVE-2014-3467_1.csv 
print_results CVE-2014-3467_2  $(CBC_DIR)/results/CVE/libtasn1/CVE-2014-3467 2 >   $(CBC_DIR)/benchmarks/CVE/CVE-2014-3467_2.csv 
print_results CVE-2014-3467_3  $(CBC_DIR)/results/CVE/libtasn1/CVE-2014-3467 3 >   $(CBC_DIR)/benchmarks/CVE/CVE-2014-3467_3.csv 
print_results CVE-2015-2806    $(CBC_DIR)/results/CVE/libtasn1/CVE-2015-2806   >   $(CBC_DIR)/benchmarks/CVE/CVE-2015-2806.csv   
print_results CVE-2015-3622    $(CBC_DIR)/results/CVE/libtasn1/CVE-2015-3622   >   $(CBC_DIR)/benchmarks/CVE/CVE-2015-3622.csv   
