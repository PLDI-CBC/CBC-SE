#!/bin/sh

run_experiment()
{
echo "* Running CVE repetition experiment $1"
cd $1
# Compiling case study
make

# Running KLEE
make all-KLEE

# Running BCGSE
make all-CBC

cd ..
}

clean_klee()
{
cd $1
make clean
}

## MAIN
run_experiment CVE-2012-1569
run_experiment CVE-2014-3467
run_experiment CVE-2015-3622
run_experiment CVE-2015-2806
