#!/bin/bash

VANILLA_KLEE=/data/klee/klee_build/bin/klee
KLEE_SMM=
KLEE=
ARTIFACT_DIR=/data/benchmarks/bugfind/klee-mm-results

# ...
OVERHEAD_DIR=${ARTIFACT_DIR}/overhead
MERGE_DIR=${ARTIFACT_DIR}/merge
MODELS_DIR=${MERGE_DIR}/models
OPTIMIZATIONS_DIR=${MERGE_DIR}/optimizations
RESOLVE_QUERIES_DIR=${MERGE_DIR}/resolve-queries
SPLIT_DIR=${ARTIFACT_DIR}/split
