# -*- coding:utf-8 -*-
 
import os
import shutil
import re
import sys
import csv

# get CBC_DIR
cbc_dir = os.environ.get('CBC_DIR')

if not cbc_dir:
    print("Error: CBC_DIR environment variable is not set.")
    exit(1)

src_dir = os.path.join(cbc_dir, "benchmarks", "CVE", "libtasn1", "")
csv_dir = os.path.join(cbc_dir, "benchmarks", "CVE", "")

KLEE_dst_2012_1569 = os.path.join(cbc_dir, "results", "CVE", "libtasn1", "CVE-2012-1569", "KLEE")
KLEE_dst_2014_3467 = os.path.join(cbc_dir, "results", "CVE", "libtasn1", "CVE-2014-3467", "KLEE")
KLEE_dst_2015_2806 = os.path.join(cbc_dir, "results", "CVE", "libtasn1", "CVE-2015-2806", "KLEE")
KLEE_dst_2015_3622 = os.path.join(cbc_dir, "results", "CVE", "libtasn1", "CVE-2015-3622", "KLEE")

CBC_dst_2012_1569 = os.path.join(cbc_dir, "results", "CVE", "libtasn1", "CVE-2012-1569", "CBC")
CBC_dst_2014_3467 = os.path.join(cbc_dir, "results", "CVE", "libtasn1", "CVE-2014-3467", "CBC")
CBC_dst_2015_2806 = os.path.join(cbc_dir, "results", "CVE", "libtasn1", "CVE-2015-2806", "CBC")
CBC_dst_2015_3622 = os.path.join(cbc_dir, "results", "CVE", "libtasn1", "CVE-2015-3622", "CBC")

CVE_result = os.path.join(cbc_dir, "benchmarks", "CVE", "CVE_results.csv")

def merge_data(): 
    for files in os.listdir(csv_dir):
        datas = []
        for fname in os.listdir(csv_dir):
            if 'csv' in fname:
                fname_path = csv_dir + fname
                with open(fname_path, "r") as csvfile:
                    reader = csv.reader(csvfile)
                    reader = list(reader)[1:]
                    for line in reader:
                        datas.append(line)
    csv_head = ['BENCHMARK', 'EXPERIMENT', 'COVERAGE', 'DFS', 'RANDOM']
    with open(CVE_result, 'w') as csvfile2:
        writer = csv.writer(csvfile2)
        writer.writerow(csv_head)
        writer.writerows(datas)


def make_clean(dstpath):
    os.chdir(dstpath)
    os.system('rm -rf *')

if __name__ == "__main__":
    print("%%  Doing the CVE reproduction experiment:  %%")

    os.chdir(src_dir)
    os.system('./run.sh')
    os.system('./print-results.sh')
    merge_data()

    if len(sys.argv) > 1:
        make_clean(KLEE_dst_2012_1569)
        make_clean(KLEE_dst_2014_3467)
        make_clean(KLEE_dst_2015_2806)
        make_clean(KLEE_dst_2015_3622)


        make_clean(CBC_dst_2012_1569)
        make_clean(CBC_dst_2014_3467)
        make_clean(CBC_dst_2015_2806)
        make_clean(CBC_dst_2015_3622)

        

